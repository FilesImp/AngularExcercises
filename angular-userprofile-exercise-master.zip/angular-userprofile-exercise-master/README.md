# User Profile exercise

### Lex Link
https://lex.infosysapps.com/en/viewer/web-module/lex_20916059959642284000?collectionId=lex_auth_0127065837892403201173&collectionType=Learning%20Path

### Preview
![Preview Image](https://github.com/Infosys-Angular-SET1/angular-userprofile-exercise/blob/master/src/assets/Preview.png?raw=true)