import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-age',
  templateUrl: './age.component.html',
  styleUrls: ['./age.component.css']
})
export class AgeComponent implements OnInit {
  yearBorn: number = 0;
  showString: string = "";

  changeBookName(a: string){
    let age = parseInt(a);
    this.yearBorn = new Date().getFullYear() - age;
    if(age > 21){
      this.showString = "You are an Adult";
    }else if(age >= 13 && age <= 21){
      this.showString = "You are a teen ager";
    }else{
      this.showString = "You are a kid";
    }
  }

  constructor() { }

  ngOnInit(): void {
  }

}
