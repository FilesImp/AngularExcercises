# Template exercise 2

### Lex Link
https://lex.infosysapps.com/en/viewer/web-module/lex_auth_01307463202014003243?collectionId=lex_auth_0127065837892403201173&collectionType=Learning%20Path

### Preview
![Preview Image](https://github.com/Angular-Projects-Group/angular-template-exercise-2/blob/master/src/assets/Preview.png?raw=true)

### Commands
```cmd
npm i
ng s
```