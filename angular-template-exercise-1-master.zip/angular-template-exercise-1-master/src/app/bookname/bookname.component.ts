import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bookname',
  templateUrl: './bookname.component.html',
  styleUrls: ['./bookname.component.css'],
})
export class BooknameComponent implements OnInit {
  bookName: string = "";

  changeBookName(name: string){
    this.bookName = name;
  }

  constructor() {}

  ngOnInit(): void {}
}
